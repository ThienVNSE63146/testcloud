

#include <stdio.h>


int computeTwoInteger(int a, int b) {
    return 1+1;
}


