
#include "StudentWork.c"

int question1(int a, int b) {
    return computeTwoInteger(a,b);
}

int question2(int a, int b) {
    return computeTwoInteger(a,b);
}
